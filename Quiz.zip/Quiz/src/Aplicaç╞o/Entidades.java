package Aplicação;

public class Entidades {

    private int pontos;
    private int vida;

    public Entidades(int pontos, int vida) {
        this.pontos = pontos;
        this.vida = vida;
    }

    public void usouVida() {
        vida -= 1;
    }

    public void ganhouPonto() {
        pontos += 2;
    }

    public void perdeuPonto() {
        pontos -= 1;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

}
