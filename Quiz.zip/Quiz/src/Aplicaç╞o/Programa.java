package Aplicação;

import java.util.Scanner;

public class Programa {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Entidades e1 = new Entidades(0, 1);
        
        System.out.println("Programa Iniciado !!!");
        System.out.println("Um quiz de 5 perguntas com 5 alternativas cada, sobre consumo elétrico!");
        System.out.println();
        System.out.println("REGRAS DO JOGO:\n1 - Você começará com 1 vida extra e 0 pontos, conforme vai acertando as questões ganha pontos"
                + "\n2 - Caso erre uma questão sua vida extra será utilizada automaticamente"
                + "\n3 - Caso erre alguma questão e ja tiver utilizado a vida extra, o programa será finalizado"
                + "\nTENHA UM BOM JOGO!!");
        System.out.println();
        System.out.println("Esta pronto para as perguntas? s / n");
        if (sc.hasNext("s")) {
            System.out.println("1) Qual a maior fonte de energia elétrica produzida no Brasil?");
            System.out.println("a) Energia Hidroelétrica\nb) Energia Termoelétrica\nc) Energia Eólica\nd) Energia Nuclear\ne) Energia Solar");
            sc.nextLine();
            while (e1.getVida() >= 0) {
                if (sc.hasNext("a")) {
                    System.out.println("[Resposta correta]");
                    e1.ganhouPonto();
                    System.out.printf("Você possui %d vida extra%n", e1.getVida());
                    System.out.printf("Parabéns!! Você tem agora %d pontos%n", e1.getPontos());
                    System.out.println("--------------------");
                    System.out.println();
                    System.out.println("2) Qual aparelho consome mais entre esses?");
                    System.out.println("a) Chuveiro elétrico\nb) Ar-condicionado\nc) Cooktop elétrico\nd) Geladeira\ne) Aparelhos em modo de espera");
                    sc.nextLine();
                } else {
                    System.out.println("[Resposta errada]");
                    if (e1.getVida() > 0) {
                        e1.usouVida();
                        e1.perdeuPonto();
                        System.out.println("Você utilizou sua vida extra");
                        System.out.printf("Você possui %d vidas extra%n", e1.getVida());
                        if (e1.getPontos() < 0) {
                            e1.setPontos(0);
                        }
                        System.out.printf("Ops!! Você perdeu ponto, agora possui %d pontos%n", e1.getPontos());
                        System.out.println("--------------------");
                        System.out.println();
                        System.out.println("2) Qual aparelho consome mais entre esses?");
                        System.out.println("a) Chuveiro elétrico\nb) Ar-condicionado\nc) Cooktop elétrico\nd) Geladeira\ne) Aparelhos em modo de espera");
                        sc.nextLine();
                    } else {
                        System.out.println("[Você perdeu]\nVocê não possui vida extra, tente novamente");
                        break;
                    }
                }

//-------------------------------------------------------------					 
                if (sc.hasNext("b")) {
                    System.out.println("[Resposta correta]");
                    e1.ganhouPonto();
                    System.out.printf("Você possui %d vida extra%n", e1.getVida());
                    System.out.printf("Parabéns!! Você tem agora %d pontos%n", e1.getPontos());
                    System.out.println("--------------------");
                    System.out.println();
                    System.out.println("3) Sabe-se que em uma tomada comum, um aparelho com potencia de 300KW/h ligado durante 2h por dia gasta R$5,40 por mês, quanto esse mesmos aparelho gastaria se estivesse ligado a uma tomada inteligente?");
                    System.out.println("a) 6,00\nb) 2,70\nc) 3,24\nd) 5,40\ne) 1,50");
                    sc.nextLine();
                } else {
                    System.out.println("[Resposta errada]");
                    if (e1.getVida() > 0) {
                        e1.usouVida();
                        e1.perdeuPonto();
                        System.out.println("Você utilizou sua vida extra");
                        System.out.printf("Você possui %d vidas extra%n", e1.getVida());
                        System.out.printf("Ops!! Você perdeu 1 ponto, agora possui %d pontos%n", e1.getPontos());
                        System.out.println("--------------------");
                        System.out.println();
                        System.out.println("3) Sabe-se que em uma tomada comum, um aparelho com potencia de 300KW/h ligado durante 2h por dia gasta R$5,40 por mês, quanto esse mesmos aparelho gastaria se estivesse ligado a uma tomada inteligente?");
                        System.out.println("a) 6,00\nb) 2,70\nc) 3,24\nd) 5,40\ne) 1,50");
                        sc.nextLine();
                    } else {
                        System.out.println("[Você perdeu]\nVocê não possui vida extra, tente novamente");
                        break;
                    }
                }

//-------------------------------------------------------
                if (sc.hasNext("c")) {
                    System.out.println("[Resposta correta]");
                    e1.ganhouPonto();
                    System.out.printf("Você possui %d vida extra%n", e1.getVida());
                    System.out.printf("Parabéns!! Você tem agora %d pontos%n", e1.getPontos());
                    System.out.println("--------------------");
                    System.out.println();
                    System.out.println("4) Qual País é o campeão em trovoadas por ano?");
                    System.out.println("a) Havaí\nb) Trinidade e Tobago\nc) Austrália\nd) Brasil\ne) Estados Unidos");
                    sc.nextLine();
                } else {
                    System.out.println("[Resposta errada]");
                    if (e1.getVida() > 0) {
                        e1.usouVida();
                        e1.perdeuPonto();
                        System.out.println("Você utilizou sua vida extra");
                        System.out.printf("Você possui %d vidas extra%n", e1.getVida());
                        System.out.printf("Ops!! Você perdeu 1 ponto, agora possui %d pontos%n", e1.getPontos());
                        System.out.println("--------------------");
                        System.out.println();
                        System.out.println("4) Qual País é o campeão em trovoadas por ano?");
                        System.out.println("a) Havaí\nb) Trinidade e Tobago\nc) Austrália\nd) Brasil\ne) Estados Unidos");
                        sc.nextLine();
                    } else {
                        System.out.println("[Você perdeu]\nVocê não possui vida extra, tente novamente");
                        break;
                    }
                }
//---------------------------------------------------------------
                if (sc.hasNext("d")) {
                    System.out.println("[Resposta correta]");
                    e1.ganhouPonto();
                    System.out.printf("Você possui %d vida extra%n", e1.getVida());
                    System.out.printf("Parabéns!! Você tem agora %d pontos%n", e1.getPontos());
                    System.out.println("--------------------");
                    System.out.println();
                    System.out.println("5) Quais Paises são os maiores consumidores de energia elétrica do Mundo?");
                    System.out.println("a) China e Brasil\nb) Russia e China\nc) Estados Unidos e Brasil\nd) Estados Unidos e Reino Unido\ne) Estados Unidos e China");
                    sc.nextLine();
                } else {
                    System.out.println("[Resposta errada]");
                    if (e1.getVida() > 0) {
                        e1.usouVida();
                        e1.perdeuPonto();
                        System.out.println("Você utilizou sua vida extra");
                        System.out.printf("Você possui %d vidas extra%n", e1.getVida());
                        System.out.printf("Ops!! Você perdeu 1 ponto, agora possui %d pontos%n", e1.getPontos());
                        System.out.println("--------------------");
                        System.out.println();
                        System.out.println("5) Quais Paises são os maiores consumidores de energia elétrica do Mundo?");
                        System.out.println("a) China e Brasil\nb) Russia e China\nc) Estados Unidos e Brasil\nd) Estados Unidos e Reino Unido\ne) Estados Unidos e China");
                        sc.nextLine();
                    } else {
                        System.out.println("[Você perdeu]\nVocê não possui vida extra, tente novamente");
                        break;
                    }
                }
                // --------------------------------------------s

                if (sc.hasNext("e")) {
                    System.out.println("[Resposta correta]");
                    e1.ganhouPonto();
                    System.out.printf("Parabéns, Você completou o quiz com %d pontos. Te vejo na proxima :)%n", e1.getPontos());
                    break;
                } else {
                    System.out.println("[Resposta errada]");
                    if (e1.getVida() > 0) {
                        e1.usouVida();
                        e1.perdeuPonto();
                        System.out.println("Você utilizou sua vida extra");
                        System.out.printf("Ops!! Você perdeu 1 ponto, agora possui %d pontos%n", e1.getPontos());
                        System.out.println();
                        System.out.println("Parabéns, Você completou o quiz, te vejo na proxima :)");
                        break;
                    } else {
                        System.out.println("Você perdeu, não possui vida extra, tente novamente");
                        break;
                    }
                }

            }
            if (e1.getPontos() == 10) {
                System.out.println("UAU!! Você completou o quiz sem errar nenhuma resposta. Parabéns!!");
            }
            System.out.println("[Programa finalizado]");

        } else {
            System.out.println("[Programa finalizado]");
        }

        sc.close();
    }
}
